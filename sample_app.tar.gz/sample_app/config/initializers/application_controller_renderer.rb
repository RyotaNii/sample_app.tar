# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '93c4df2dff823e75887d4cf44940cf3a809b635a5476a9d8a5e067f72f97a72b34bbcd8440b82cd446afe87ee919cc0b9bf815762aedecd4ed6b5c6e64ca8aa3'